import modal
import subprocess
import os

# --- CONFIGURATION ---
# App name for Modal dashboard visibility
app = modal.App("maas-bfcl-gemini-search")

# 1. Image definition: Defines the required environment inside the container.
maas_image = modal.Image.debian_slim(python_version="3.10").pip_install_from_requirements(
    "requirements.txt"  # Install dependencies from your local requirements file
).apt_install("git").run_commands(
    # Step 1: Clone the repository
    "git clone https://github.com/bingreeky/MaAS.git /root/MaAS",
    
    # FINAL FIX: Install the local package as a module, bypassing strict dependency checks.
    # This relies on Step 1 (pip_install_from_requirements) having already satisfied
    # all non-hardcoded dependencies.
    "python -m pip install -e /root/MaAS --no-deps" 
)

# 2. Main Function: Defines resources and the execution flow.
@app.function(
    image=maas_image,
    # Attaching the Gemini secret created earlier
    secrets=[modal.Secret.from_name("gemini-key")],
    # Request a GPU for controller training and LLM speed
    gpu="A10G", 
    timeout=10800 # 3 hours
)
def run_maas_search():
    print("Starting MaAS architecture search with BFCL benchmark (Gemini 2.5 Flash)...")
    
    MAAS_DIR = "/root/MaAS"
    
    # Execution command using arguments from optimize.py
    command = [
        "python", 
        f"{MAAS_DIR}/examples/maas/optimize.py", 
        "--dataset", "bfcl_v4",      # Your new registered dataset name
        "--sample", "10",           # Small test run
        "--round", "1",             # Run for 1 round
        "--opt_model_name", "gemini-2.5-flash", 
        "--exec_model_name", "gemini-2.5-flash",
        # Use default optimized_path
    ]
    
    try:
        print(f"Executing: {' '.join(command)}")
        result = subprocess.run(
            command, 
            check=True, 
            cwd=MAAS_DIR, 
            capture_output=True, 
            text=True
        )
        print("Search Output (stdout):\n", result.stdout)
        
    except subprocess.CalledProcessError as e:
        # NOTE: This error block will now catch a 'KeyError: bfcl_v4' if the data registration is missing.
        print(f"MaAS Search FAILED. Stderr: {e.stderr}")
        raise

    print("MaAS search completed.")