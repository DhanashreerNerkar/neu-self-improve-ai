"""Rankers init"""
