from typing import Dict, List

class ExperimentConfig:
    def __init__(self, dataset: str, question_type: str, operators: List[str]):
        self.dataset = dataset
        self.question_type = question_type
        self.operators = operators

EXPERIMENT_CONFIGS: Dict[str, ExperimentConfig] = {
    # Existing Datasets (Kept as references)
    "MATH": ExperimentConfig(
        dataset="MATH",
        question_type="math",
        operators=["Generate", "GenerateCoT", "MultiGenerateCoT", "ScEnsemble", "Programmer", "SelfRefine", "EarlyStop"],
    ),
    "GSM8K": ExperimentConfig(
        dataset="GSM8K",
        question_type="math",
        operators=["Generate", "GenerateCoT", "MultiGenerateCoT", "ScEnsemble", "Programmer", "SelfRefine", "EarlyStop"],
    ),
    "HumanEval": ExperimentConfig(
        dataset="HumanEval",
        question_type="code",
        operators=["Generate", "GenerateCoT", "MultiGenerateCoT", "ScEnsemble", "Test", "SelfRefine", "EarlyStop"],
    ),
    
    # === NEW ENTRY FOR BFCL V4 ===
    "bfcl_v4": ExperimentConfig(
        dataset="BFCL_V4",
        # Use 'function_call' or 'agentic' if MaAS supports it, otherwise use 'code'
        question_type="code", 
        operators=[
            "Generate", 
            "GenerateCoT", 
            "MultiGenerateCoT", 
            "Programmer", 
            "SelfRefine", 
            "EarlyStop",
            "ScEnsemble" # Added for robustness
        ],
    ),
}
'''from typing import Dict, List

class ExperimentConfig:
    def __init__(self, dataset: str, question_type: str, operators: List[str]):
        self.dataset = dataset
        self.question_type = question_type
        self.operators = operators

EXPERIMENT_CONFIGS: Dict[str, ExperimentConfig] = {
    "MATH": ExperimentConfig(
        dataset="MATH",
        question_type="math",
        operators=["Generate", "GenerateCoT", "MultiGenerateCoT", "ScEnsemble", "Programmer", "SelfRefine", "EarlyStop"],
    ),
    "GSM8K": ExperimentConfig(
        dataset="GSM8K",
        question_type="math",
        operators=["Generate", "GenerateCoT", "MultiGenerateCoT", "ScEnsemble", "Programmer", "SelfRefine", "EarlyStop"],
    ),
    "HumanEval": ExperimentConfig(
        dataset="HumanEval",
        question_type="code",
        operators=["Generate", "GenerateCoT", "MultiGenerateCoT", "ScEnsemble", "Test", "SelfRefine", "EarlyStop"],
    ),
}
'''
